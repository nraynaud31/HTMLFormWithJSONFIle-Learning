// Constants
const express = require("express");
const body_parser = require("body-parser")
const fs = require("fs")
const app = express();

// Static serv
app.use(express.static("web"));
app.use(body_parser())

// App listening
app.listen(80, function() {
    console.log("Server started!");
});

app.post("", function(req, res) {
    fs.readFile("web/crm.json", function(err, data) {
        if(err) { 
            console.log(err) 
            res.sendStatus(404)
        } else {
            console.log("Received new customer")
            let json = {
                customers: []
            }
            try {
                json = JSON.parse(data)
            } catch (err) {}
            json.customers.push({
                id: Object.keys(json.customers).length + 1,
                last_name: req.body.last_name,
                first_name: req.body.first_name,
                phone: req.body.phone,
                email: req.body.email,
                description: req.body.description
            })
            fs.writeFile("web/crm.json", JSON.stringify(json, null, 1), function(err) {
                if(err) {
                    console.log(err)
                    res.sendStatus(404)
                } else {
                    console.log("Successfully added new customer to JSON file")
                    res.sendStatus(200)
                }
            })
        }
    })
})