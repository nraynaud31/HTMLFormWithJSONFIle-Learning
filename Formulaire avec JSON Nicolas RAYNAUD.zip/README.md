Prérequis: Nodejs (Testé sur nodejs 14)

1. Extraire
2. Installer les dépendances
	-> npm install
3. Démarrer le serveur dans le terminal
	-> npm start
4. Aller sur http://localhost/
5. Accéder au service.
